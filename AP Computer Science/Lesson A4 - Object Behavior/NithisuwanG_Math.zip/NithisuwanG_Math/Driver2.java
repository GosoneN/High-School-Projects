
public class Driver2 {
	//Runs the program
	public static void main (String [] args)
	{
		Math myMath = new Math();
		myMath.draw();
		
	}

}
